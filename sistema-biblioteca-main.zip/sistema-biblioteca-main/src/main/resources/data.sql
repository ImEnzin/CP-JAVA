INSERT INTO usuario (nome, email) VALUES ('Fulano', 'fulano@ex.com');

INSERT INTO livro (titulo, autor, ano_publicacao, status)
VALUES ('Clean Code', 'Robert C. Martin', 2008, 'DISPONIVEL');

package com.example.biblioteca.model;

public enum StatusLivro {
    DISPONIVEL,
    EMPRESTADO
}

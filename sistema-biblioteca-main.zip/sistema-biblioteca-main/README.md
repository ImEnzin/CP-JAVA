# 📚 Sistema de Biblioteca - Spring Boot

## 🎯 Descrição
Sistema completo de gerenciamento de biblioteca desenvolvido em Java com Spring Boot para controle de livros, usuários e empréstimos.

## 🚀 Como Executar

### Pré-requisitos
- Java 17
- Maven

### Execução:
```bash
./mvnw clean spring-boot:run
